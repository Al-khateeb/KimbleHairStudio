//
//  PhotoWithHairViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/05/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class PhotoWithHairViewController: BaseViewController {

    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var photoView: UIView!
    var hairImageView: DraggableImageView!


    //MARK - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        AppData.sharedInstance.currentImageView = nil
        
        photoImageView.image = AppData.sharedInstance.currentImage
  

        var hairImage:UIImage? = nil

        if let imageUrl = AppData.sharedInstance.selectedStyle?.colors?["Black"] {
            let url = URL(string: imageUrl)
            let data = try? Data(contentsOf: url!)
            
            hairImage = UIImage(data:data!)
        }
        else {
            if let imageUrl = AppData.sharedInstance.selectedStyle?.colors?.values.first {
                let url = URL(string: imageUrl)
                let data = try? Data(contentsOf: url!)
                
                hairImage = UIImage(data:data!)
            }
            else {
                let alert = UIAlertController(title: "Error", message: "Can't load hair images", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
        hairImageView = DraggableImageView.init(image: hairImage)

        hairImageView.contentMode = .scaleAspectFit
        hairImageView.frame = photoImageView.frame
        
        self.photoView.addSubview(hairImageView)
    }
    
    override func customizeSidebar() {
        self.sidebar?.shareButton.isEnabled = false
        
        self.sidebar?.shareButton.setTitleColor(.gray, for: .normal)
        
        self.sidebar?.retakeButton.addTarget(self, action: #selector(retakeButtonPressed(_:)), for: .touchUpInside)
        self.sidebar?.newStyleButton.addTarget(self, action: #selector(newStyleButtonPressed(_:)), for: .touchUpInside)
        self.sidebar?.editColorButton.addTarget(self, action: #selector(editColorButtonPressed(_:)), for: .touchUpInside)
    }

    
    override func viewWillAppear(_ animated: Bool) {
        hairImageView.setBorderHidden(isHidden: false)
        
        if (AppData.sharedInstance.currentImageView != nil) {
            AppData.sharedInstance.currentImageView?.setBorderHidden(isHidden: false)
            self.photoView.addSubview(AppData.sharedInstance.currentImageView!)
        }
    }
    
    //Mark: - Actions
    
    @IBAction func acceptButtonPressed(_ sender: Any) {
        hairImageView.setBorderHidden(isHidden: true)
        
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: false) { (Timer) in
            self.performSegue(withIdentifier: "SelectionOfHairSegue", sender: nil)
        }
    }
    
    @IBAction override func retakeButtonPressed(_ sender: UIButton) {
        _ = self.navigationController?.popToViewController((self.navigationController?.viewControllers[1])!, animated: true)
    }
    
    @IBAction override func newStyleButtonPressed(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction override func editColorButtonPressed(_ sender: UIButton) {
        self.performSegue(withIdentifier: "EditColorSegue", sender: self)
    }
    
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        AppData.sharedInstance.currentImageView = self.hairImageView
    }

}
