//
//  colorHairCollectionViewCell.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/02/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class ColorHairCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var colorHairImageView: UIImageView!
    
}
