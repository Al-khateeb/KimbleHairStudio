//
//  AcceptPhotoViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/07/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class AcceptPhotoViewController: BaseViewController {

    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var photoView: UIView!
    var hairImageView: DraggableImageView!
    
    //Mark: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        photoImageView.image = AppData.sharedInstance.currentImage
        
        let hairImage = UIImage.init(named: AppData.sharedInstance.selectedHairName!)

        hairImageView = DraggableImageView.init(image: hairImage)
        hairImageView.contentMode = .scaleAspectFit
        hairImageView.frame = photoImageView.frame
        
        self.photoView.addSubview(hairImageView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        hairImageView.setBorderHidden(isHidden: false)        
    }
    
    //Mark: - Actions

    @IBAction func acceptButtonPressed(_ sender: Any) {
        hairImageView.setBorderHidden(isHidden: true)
        
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: false) { (Timer) in
            self.performSegue(withIdentifier: "SelectionOfHairSegue", sender: nil)
        }
    }
}
