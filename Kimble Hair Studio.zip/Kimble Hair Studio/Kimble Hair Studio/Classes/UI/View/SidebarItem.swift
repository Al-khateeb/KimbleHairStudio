//
//  SidebarItem.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 02/24/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class SidebarItem: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        let border = CALayer()
        let width = CGFloat(1.0)
        //border.borderColor = (UIColor(red: 257/255, green: 247/255, blue: 247/255, alpha: 1) as! CGColor)
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height: self.frame.size.height)
        
        border.borderWidth = width
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
    

}
