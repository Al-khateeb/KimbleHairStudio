//
//  PhotoCollectionViewCell.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/15/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photoImageView: UIImageView!
    
}
