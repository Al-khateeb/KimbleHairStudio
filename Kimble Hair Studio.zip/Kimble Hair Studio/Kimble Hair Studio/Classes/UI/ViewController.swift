//
//  ViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 02/23/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

