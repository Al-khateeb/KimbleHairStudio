//
//  SidebarView.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 02/25/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class SidebarView: UIView {

    @IBOutlet weak var retakeButton: UIButton!
    @IBOutlet weak var newStyleButton: UIButton!
    @IBOutlet weak var editColorButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code

    }
    
    

//    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
//        self.isHidden = true
//       
//    }
    
    
    

    

}
