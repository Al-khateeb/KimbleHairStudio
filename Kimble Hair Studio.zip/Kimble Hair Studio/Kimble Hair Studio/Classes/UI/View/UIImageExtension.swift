//
//  UIImageExtension.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/27/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

extension UIImage{

    convenience init(view: UIView) {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.isOpaque, 0.0)
        view.drawHierarchy(in: view.bounds, afterScreenUpdates: false)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        self.init(cgImage: (image?.cgImage)!)
    }
}
