//
//  SelectionOfHairColorViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/08/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class SelectionOfHairColorViewController: BaseViewController , UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var colorHairCollectionView: UICollectionView!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var photoView: UIView!
    
    var prevScreenHairCGAffineTransform: CGAffineTransform!

    var hairImageView: UIImageView!
    
//    let countItem = 4;
    
    var dataDictionary:[String:String]? = nil
    var keysArray: [String]?  = nil
    
    //MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        self.photoImageView.image = AppData.sharedInstance.currentImage
        self.dataDictionary = AppData.sharedInstance.selectedStyle?.colors
        self.keysArray = Array((self.dataDictionary?.keys)!)
    }

    override func customizeSidebar() {
        self.sidebar?.editColorButton.isEnabled = false
        
        self.sidebar?.retakeButton.addTarget(self, action: #selector(retakeButtonPressed(_:)), for: .touchUpInside)
        self.sidebar?.newStyleButton.addTarget(self, action: #selector(newStyleButtonPressed(_:)), for: .touchUpInside)
        self.sidebar?.shareButton.addTarget(self, action: #selector(shareButtonPressed(_:)), for: .touchUpInside)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        AppData.sharedInstance.currentImageView?.setBorderHidden(isHidden: true)
        self.hairImageView = AppData.sharedInstance.currentImageView
        self.photoView.addSubview(AppData.sharedInstance.currentImageView!)
    }
    
    //MARK: - UICollectionViewDataSource -
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (self.keysArray?.count)!
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath as IndexPath) as! ColorHairCollectionViewCell
        cell.contentView.backgroundColor = UIColor.red
        
        let key = (self.keysArray?[indexPath.row])!

        switch key {
        case "Black":
            cell.colorHairImageView.image = UIImage.init(named: "choose_hair_brown.png");
            break
        case "Red":
            cell.colorHairImageView.image = UIImage.init(named: "choose_hair_red.png");
            break
        case "Yellow":
            cell.colorHairImageView.image = UIImage.init(named: "choose_hair_yellow.png");
            break
        case "White":
            cell.colorHairImageView.image = UIImage.init(named: "choose_hair_white.png");
            break
        default:
            break
        }
        
        return cell
    }
    
    var collectionViewContentSize: CGSize {
        return CGSize(width: colorHairCollectionView.frame.size.width/2, height: colorHairCollectionView.frame.size.height)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: colorHairCollectionView.frame.size.width/2, height: colorHairCollectionView.frame.size.height)
    }
    
    //MARK: - UICollectionViewDelegete -

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        let key = self.keysArray?[indexPath.row]
        let urlPath = dataDictionary?[key!]
        let url = URL(string: urlPath!)
        self.hairImageView.sd_setImage(with: url, completed: nil)
    }
    
    //MARK: - Share
    func shareImage () {
        let image = UIImage.init(view: self.photoView)

        let imageToShare = [ image ]
        let activityViewController = UIActivityViewController(activityItems: imageToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash

        activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop ]
        
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    //MARK: - Actions
    
    @IBAction func leftHairColor(_ sender: Any) {
        let currentItem = getCurrentIndexPath()
        
        if currentItem.row == 0 {
            return
        }
        
        let nextItem = IndexPath.init(row: currentItem.row - 1, section: currentItem.section)
        
        colorHairCollectionView.scrollToItem(at: nextItem, at: UICollectionView.ScrollPosition.right, animated: true)
    }
    
    @IBAction func rightHairColor(_ sender: Any) {
        let currentItem = getCurrentIndexPath()
        let nextItem = IndexPath.init(row: currentItem.row + 1, section: currentItem.section)
        if nextItem.row < (self.keysArray?.count)! {
            colorHairCollectionView.scrollToItem(at: nextItem, at: UICollectionView.ScrollPosition.right, animated: true)
        }
    }
    
    @IBAction override func retakeButtonPressed(_ sender: UIButton) {
        _ = self.navigationController?.popToViewController((self.navigationController?.viewControllers[1])!, animated: true)
    }
    
    @IBAction override func newStyleButtonPressed(_ sender: UIButton) {
        _ = self.navigationController?.popToViewController((self.navigationController?.viewControllers[2])!, animated: true)
   }
    
    @IBAction override func editColorButtonPressed(_ sender: UIButton) {
    
    }
    
    @IBAction override func shareButtonPressed(_ sender: UIButton) {
        self.shareImage()
    }

    //MARK: - Methods
    
    private func getCurrentIndexPath() -> IndexPath {
        
        let visibleItems = colorHairCollectionView.indexPathsForVisibleItems
        
        let sortedIndexPaths = visibleItems.sorted();
            
        return sortedIndexPaths.last!;
        
    }

}
