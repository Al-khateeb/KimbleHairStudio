//
//  HelpViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/04/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class HelpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction  func backClick(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
 }
