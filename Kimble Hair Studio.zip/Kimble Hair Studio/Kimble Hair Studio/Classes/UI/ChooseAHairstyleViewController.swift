//
//  ChooseAHairstyleViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/02/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

import SDWebImage

class ChooseAHairstyleViewController: BaseViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
 
    @IBOutlet weak var photoCollectionView: UICollectionView!
    
    var collectionViewArray: [Style] = []
    
    //MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()

        collectionViewArray = AppData.getHairForLenght(lenght: .all)
    }
    
    override func customizeSidebar() {
        self.sidebar?.newStyleButton.isEnabled = false
        self.sidebar?.editColorButton.isEnabled = false
        self.sidebar?.shareButton.isEnabled = false
        
        self.sidebar?.editColorButton.setTitleColor(.gray, for: .normal)
        self.sidebar?.shareButton.setTitleColor(.gray, for: .normal)
        
        self.sidebar?.retakeButton.addTarget(self, action: #selector(makePhotoButtonPressed(_:)), for: .touchUpInside)
    }


    //MARK: - UICollectionViewDataSource

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return collectionViewArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! PhotoCollectionViewCell
        
        let style = self.collectionViewArray[indexPath.row] as Style
        
        let imageUrl = URL(string:style.preview)
        
        cell.photoImageView.sd_setImage(with: imageUrl, placeholderImage: UIImage(named: "preview_image"))
        return cell
    }
    
    //MARK: - UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let screenWidth = self.view.bounds.size.width - 4 - 4;
        return CGSize(width: screenWidth/3, height: 1.3*screenWidth/3);
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        AppData.sharedInstance.selectedHairName = "hair_1_brown.png"
        let style = self.collectionViewArray[indexPath.row] as Style
        AppData.sharedInstance.selectedStyle = style
        self.performSegue(withIdentifier: "photoWithHairSegue", sender: nil)
    }
    
    //MARK: - Actions
    
    @IBAction func allButtonClick(_ sender: Any) {
        //collectionViewArray = allHair
        collectionViewArray = AppData.getHairForLenght(lenght: .all)
        photoCollectionView.reloadData()
    }
    
    
    @IBAction func longHairButtonClick(_ sender: Any) {
        //collectionViewArray = longHair
        collectionViewArray = AppData.getHairForLenght(lenght: .long)
        photoCollectionView.reloadData()
    }
    

    @IBAction func shirtHairButtonClick(_ sender: Any) {
//        collectionViewArray = shortHair
        collectionViewArray = AppData.getHairForLenght(lenght: .short)
        photoCollectionView.reloadData()
    }
    
    @IBAction func wingsButtonPressed(_ sender: Any) {
        //collectionViewArray = []
        collectionViewArray = AppData.getHairForLenght(lenght: .wings)
        photoCollectionView.reloadData()
    }
    
    @IBAction func makePhotoButtonPressed(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
}
