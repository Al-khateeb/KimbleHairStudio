//
//  BaseViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 02/23/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    var sidebar : SidebarView? = nil
    
    @IBOutlet weak var retakeButton: UIButton!
    @IBOutlet weak var newStyleButton: UIButton!
    @IBOutlet weak var editColorButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!

    func initSidebar ()
    {
        let nib = UINib(nibName: "SidebarView", bundle: nil)
        
        let view  = nib.instantiate(withOwner: nil, options: nil)[0] as! SidebarView
        view.frame.origin.x = self.view.bounds.size.width - view.frame.size.width;
        view.frame.origin.y = 65;
        view.isHidden = true
        sidebar = view
        self.view.addSubview(view)
        
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.hideView(sender:)))
        view.addGestureRecognizer(tap)
    }
    
    func customizeSidebar() {
        
    }
    
/*    func customizeTabBarButtons ()
    {
        self.retakeButton.centerLabelVerticallyWithPadding(spacing: 5)
        self.newStyleButton.centerLabelVerticallyWithPadding(spacing: 2)
        self.editColorButton.centerLabelVerticallyWithPadding(spacing: 6)
        self.shareButton.centerLabelVerticallyWithPadding(spacing: 5)
    }
*/
    override func viewDidLoad() {
        super.viewDidLoad()

        self.initSidebar()
        self.customizeSidebar()
//        self.customizeTabBarButtons()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        sidebar?.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func sidebarClick(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.3) {
            self.sidebar?.isHidden =  !(self.sidebar?.isHidden)!
        }
    }
    
    // MARK: IBAction
    
    @IBAction func retakeButtonPressed(_ sender: UIButton) {
    }
    
    @IBAction func newStyleButtonPressed(_ sender: UIButton) {
    }
    
    @IBAction func editColorButtonPressed(_ sender: UIButton) {
    }

    @IBAction func shareButtonPressed(_ sender: UIButton) {
    }

    
    @IBAction  func backClick(_ sender: UIButton) {
        
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func helpClick(_ sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil);
        let vc = storyboard.instantiateViewController(withIdentifier: "HelpViewController") ;
        self.present(vc, animated: true, completion: nil);
    }
    

    @objc public func hideView(sender: UITapGestureRecognizer) {
        sidebar?.isHidden = true;
    }


    
  /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
