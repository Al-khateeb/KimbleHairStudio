//
//  InstructionsViewController.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 02/25/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class InstructionsViewController: BaseViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate
{
    //MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        AppData.loadDataFromServer()
    }
 
    override func customizeSidebar() {
        self.sidebar?.newStyleButton.isEnabled = false
        self.sidebar?.editColorButton.isEnabled = false
        self.sidebar?.shareButton.isEnabled = false
        
        self.sidebar?.newStyleButton.setTitleColor(.gray, for: .normal)
        self.sidebar?.editColorButton.setTitleColor(.gray, for: .normal)
        self.sidebar?.shareButton.setTitleColor(.gray, for: .normal)
        
        self.sidebar?.retakeButton.addTarget(self, action: #selector(makePhotoClick(_:)), for: .touchUpInside)
    }

    //MARK: - Camera
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
// Local variable inserted by Swift 4.2 migrator.
let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)


        self.performSegue(withIdentifier: "newStyleSegue", sender: nil)

        let image = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)]
            as! UIImage
        
        AppData.sharedInstance.currentImage = image
        
        self.dismiss(animated: false, completion: nil)
    }
    
    func openCamera () {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = UIImagePickerController.SourceType.camera;
//        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
        imagePicker.allowsEditing = false
        self.present(imagePicker, animated: true, completion: nil)
    }

    //MARK: - Actions
    @IBAction func makePhotoClick(_ sender: UIButton) {
        self.openCamera()
    }    
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
	return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
	return input.rawValue
}
