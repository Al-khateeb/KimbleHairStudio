//
//  AppData.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/07/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class AppData: NSObject
{
    let SERVER_URL = "http://kimkimble.megabomba.net/admin/api/"
    
    static let sharedInstance = AppData()
    
    var currentImage: UIImage?
    var currentImageView: DraggableImageView?
    var savedImage: UIImage?
    
    var selectedHairName: String?
    var selectedStyle: Style?
    
//    var lengthsArray = [] as [String]
    var stylesArray = [] as [Style]


    override init() {
        super.init()
    }

    static func loadDataFromServer() {
        let url = URL(string: self.sharedInstance.SERVER_URL)

        URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
            guard let data = data, error == nil else {
                let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                if let app = UIApplication.shared.delegate as? AppDelegate, let window = app.window {
                    window.rootViewController?.present(alert, animated: true, completion: nil)
                }

                return
            }
        
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String:Any]
                //self.lengthsArray = (json["hair_lengths"] as? [String])!
                
                let styles = json["styles"] as? [[String: Any]] ?? []
                
                for style in styles {

                    let myStyle = Style()
                    
                    myStyle.name = style["style_name"] as! String

                    let hairLenght = style["hair_length"] as! String
                    if hairLenght == "Short" {
                        myStyle.length = .short
                    }
                    else if hairLenght == "Long" {
                        myStyle.length = .long
                    }
                    else if hairLenght == "Wings" {
                        myStyle.length = .wings
                    }

                    myStyle.preview = style["preview"] as! String
                    myStyle.colors = style["colors"] as? [String : String]
                    self.sharedInstance.stylesArray.append(myStyle)
                    print(self.sharedInstance.stylesArray)
                }
                
            } catch let error as NSError {
                print(error)
            }
        }).resume()
    }
    
    static func getHairForLenght(lenght:HairLenght) -> [Style] {
        if lenght == .all {
            return self.sharedInstance.stylesArray
        }
        
        var filterArray: [Style] = []
        
        for style in self.sharedInstance.stylesArray {
            if style.length == lenght {
                filterArray.append(style)
            }
        }
        
        return filterArray
    }
    
}
