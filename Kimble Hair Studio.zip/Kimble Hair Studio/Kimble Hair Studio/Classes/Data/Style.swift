//
//  Style.swift
//  JSONTest
//
//  Created by Anas Al-khateeb on 02/23/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

enum HairLenght {
    case short
    case long
    case wings
    case all
}

class Style: NSObject {
    var name: String = ""
    var length:HairLenght = .all
    var preview:String = ""
    var colors:[String: String]?
}
