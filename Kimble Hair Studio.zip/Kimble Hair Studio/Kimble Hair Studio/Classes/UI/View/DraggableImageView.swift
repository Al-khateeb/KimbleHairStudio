//
//  DraggableImageView.swift
//  Kimble Hair Studio
//
//  Created by Anas Al-khateeb on 03/15/18.
//  Copyright © 2018 Anas Al-khateeb. All rights reserved.
//

import UIKit

class DraggableImageView: UIImageView {

    fileprivate var touchesCount = 0
    
    fileprivate var lastAngle: CGFloat = 0
    fileprivate var lastTwoPointsDistance: CGFloat = 0.0
    fileprivate var lastMoveLocation: CGPoint = CGPoint(x: 0, y: 0)

    //MARK: - Init -
    
    override init(image: UIImage!) {
        super.init(image: image)
        
        self.isUserInteractionEnabled = true   //< w00000t!!!1
        self.isMultipleTouchEnabled = true
        
        self.setBorderHidden(isHidden: false)
        
        self.transform = CGAffineTransform.identity
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setBorderHidden (isHidden:Bool) {
        if isHidden {
            self.layer.borderWidth = 0
        }
        else {
            self.layer.borderWidth = 1
            self.layer.borderColor = UIColor(red:222/255.0, green:225/255.0, blue:227/255.0, alpha: 1.0).cgColor
        }
    }
}

//MARK: - Affine logic 

extension DraggableImageView {

    func configureMove(for event:UIEvent) {
        lastMoveLocation = (event.allTouches?.first?.location(in: self.superview))!
    }
    
    func configureScaleAndRotate(for event:UIEvent) {
        lastAngle = getAngleBetweenPoints(in: event)
        lastTwoPointsDistance = getDistanceBetweenPoints(in: event)
    }
    
    func makeMove(for event:UIEvent) {
        let touch = (event.allTouches?.first)!
        let currentTouchLocation = touch.location(in: self.superview)
        let distance = CGVector(dx: currentTouchLocation.x - lastMoveLocation.x, dy: currentTouchLocation.y - lastMoveLocation.y)
        
        self.center = CGPoint(x:self.center.x + distance.dx, y:self.center.y + distance.dy)

        lastMoveLocation = currentTouchLocation
    }
    
    func makeScaleAndRotate(for event:UIEvent) {
        let newDistance = getDistanceBetweenPoints(in: event)
        
        let scale = newDistance/lastTwoPointsDistance
        lastTwoPointsDistance = newDistance
      
        let angle = getAngleBetweenPoints(in: event)
        var rotateAngle = angle - lastAngle

        if abs(rotateAngle) > 1 {
            rotateAngle = 0
        }
        
        var transform = self.transform.rotated(by: rotateAngle)
        transform = transform.scaledBy(x: scale, y: scale)
        
        self.transform = transform
        
        lastAngle = angle
    }
    
    func getTouchLocations(from event:UIEvent) -> (CGPoint,CGPoint) {
        let touch1 = (event.allTouches?.first)!
        let location1 = touch1.location(in: self.superview)
        
        let touch2Index = event.allTouches?.index(after: (event.allTouches?.index(of: touch1))!)
        let touch2 = (event.allTouches?[touch2Index!])!
        let location2 = touch2.location(in: self.superview)
        
        return (location1, location2)
    }
    
    func getDistanceBetweenPoints(in event:UIEvent) -> CGFloat {
        
        let (location1, location2) = getTouchLocations(from: event)
        
        let vector = CGVector(dx: location1.x - location2.x, dy: location1.y - location2.y)
        let distance = sqrt(vector.dx * vector.dx + vector.dy * vector.dy )
        
        return distance
    }
    
    func getAngleBetweenPoints(in event:UIEvent) -> CGFloat {
        
        let (location1, location2) = getTouchLocations(from: event)
        
        let angle = atan2((location2.y - location1.y), (location2.x - location1.x))
        return angle
    }
}

//MARK: - Override touch functions

extension DraggableImageView {

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if event?.allTouches?.count == 1 {
            configureMove(for: event!)
        }
        else if event?.allTouches?.count == 2 {
            configureScaleAndRotate(for: event!)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if event?.allTouches?.count == 1 {
            if touchesCount != 1 {
                configureMove(for: event!)
            }
            else {
                makeMove(for: event!)
            }
        }
        else if event?.allTouches?.count == 2 {
            if touchesCount != 2 {
                configureScaleAndRotate(for: event!)
            }
            else {
                makeScaleAndRotate(for: event!)
            }
         }
        
        touchesCount = (event?.allTouches?.count)!
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchesCount = 0
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchesCount = 0
    }
}
